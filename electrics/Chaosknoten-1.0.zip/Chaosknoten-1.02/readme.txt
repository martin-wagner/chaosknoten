Board does not have silkscreen.
